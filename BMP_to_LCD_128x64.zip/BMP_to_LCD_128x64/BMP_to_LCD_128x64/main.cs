﻿using System;  
using System.IO;
using System.Drawing;  
using System.Windows.Forms;  
  
class Program{
	static Form mainForm = new Form(); // Создаем основное окно формы
	static TextBox text_box = new TextBox(); // Создаем контейнер для отображения текста (кода)
	static PictureBox picture_box  = new PictureBox();  // Создаем контейнер для отображения BMP
	static TrackBar slider = new TrackBar(); // Создаем ползунок
	
	[STAThread] // Нужно для работы с COM (OpenFileDialog)
	
    public static  void Main(){    // Функция Main() запускает приложение и конструктор формы  
        
    	mainForm.Text = "BMP_to_LCD_128x64"; // Задаем заголовок формы
    	//mainForm.WindowState = FormWindowState.Maximized;
    	mainForm.Width = 800;   // Ширина формы
    	mainForm.Height = 800;   // Высота формы
        
		Button button_start = new Button(); // Создаем кнопку на форме  
        button_start.Text = "Открыть BMP"; // Текст кнопки  
        button_start.Width = 150;   // Ширина кнопки
        button_start.Left = 10;  		// Отступ кнопки от левого края формы 
        button_start.Top = 10;  		// Отступ кнопки от верхнего края формы 
        button_start.Parent = mainForm;  // Устанавливаем принадлежность кнопки форме 
        button_start.Click += new EventHandler(button_start_Click);  // Устанавливаем обработчик нажатия кнопки    		
            
        Label label_info = new Label(); // Создаем текстовую метку на форме  
        label_info.Text = "Нажмите кнопку \"Открыть BMP\" и укажите путь к файлу с расширением bmp и черно-белым однобитовым изображением 128х64 пикселов.\nВ текстовом окне ниже будет выведен код с массивом картинки, где каждый байт массива - это 8 вертикальных пикселов, начиная от левого верхнего угла экрана слева направо и сверху вниз.";  
        label_info.Top = 50; // Отступ от верха формы  
        label_info.Left = 10; // Отступ от левого края формы  
        label_info.Width = mainForm.Width - 20; // Ширина метки меньше чем у формы  
        label_info.Height = 80; // Высота метки как у формы минус отступ сверху  
        label_info.Font = new Font("Arial", 11); // Устанавливаем шрифт метки  
        label_info.Parent = mainForm; // Устанавливаем принадлежность метки форме
            
        text_box.Top = 130; // Отступ от верха формы  
        text_box.Left = 10; // Отступ от левого края формы 
		text_box.Multiline = true; 
		text_box.ScrollBars = ScrollBars.Both; 	
        text_box.Width = mainForm.Width - 40; // Ширина TextBox меньше чем у формы  
        text_box.Height = 300; // Высота TextBox как у формы минус отступ сверху 
        text_box.Parent = mainForm; // Устанавливаем принадлежность TextBox форме
 		
        picture_box.Top = 450; // Высота контейнера
        picture_box.Left = 10; // Отступ от левого края формы 
        picture_box.Width = 128 * 4; // Ширина контейнера
        picture_box.Height = 64 * 4; // Высота контейнера
		picture_box.Parent = mainForm; // Устанавливаем принадлежность PictureBox форме
		
		slider.Top = 10; // Высота контейнера
        slider.Left = 200; // Отступ от левого края формы 
        slider.Width = 550; // Ширина контейнера
		slider.Minimum = 0; // Минимальное значение
		slider.Maximum = 255; // Максимальное значение
		slider.Scroll += new EventHandler(slider_changed);  // Устанавливаем обработчик изменения значения слайдера   		
 			
        Application.Run(mainForm); // Запускаем приложение и форму  
  
    }  
    
	static Bitmap bmp; // = new Bitmap(filename);				// Создаем BMP из пути к файлу картинки
    static Bitmap bmp_on_form = new Bitmap(128 * 4, 64 * 4);	// Создаем BMP из пути к файлу картинки
    
    static void print_and_draw(){ // Выводит картинку на экран, сохраняет код в файл и в печатает код в текстовое окно
    	Color col = bmp.GetPixel(0, 0);		
        int px = col.B;	// Приводим значение цвета к голубому (из него получим черный или белый)
    
        string code = "static unsigned char lcd_ar[8][128] = \n{\n"; // Строка с кодом массива
		int px_bool;	// Целочисленное значение цвета пиксела 0 или 1
		int bt; // Значение байта с 8ю пикселами
		for(int p = 0; p < 8; p++){ // Перебираем страницы (строки шириной 8 пикселов)
			code += "    {"; // Добавляем код
            for(int x = 0; x < 128; x++){ // Перебираем столбцы
				bt = 0; // Обнуляем значение байта (8 пиксел)
				for(int b = 0; b < 8; b++){ // Формируем байт из 8 пикселов
					col = bmp.GetPixel(x, p * 8 + b); // Получаем значение цвета пиксела
					int porog = slider.Value; // Порог выше которого считаем цвет 
					px_bool = col.B > porog ? 1 : 0;	// Приводим значение цвета к голубому (из него получим черный или белый 0 или 1)
					bt |= (px_bool ^ 1) << b;	// Добавляем значение пиксела к байту (инвертируем значение бита и сдвигаем его на свое место)
					
					if(px_bool > 0){ // Цвет для отображения увеличенной картинки на экране
						col = Color.White; // Белый цвет
					}else{
						col = Color.Black; // Черный цвет
					}
					for(int xn = 0; xn < 4; xn++){
						for(int yn = 0; yn < 4; yn++){
							bmp_on_form.SetPixel(x * 4 + xn, (p * 8 + b)*4 + yn, col);
						}
					}
				}
				if(x % 8 == 0){ // Каждые 8 байт добавляем перенос строки
					code += "\n    "; 
				}
				code += bt.ToString() + ", "; // Добавляем код со значениями пиксела
            }
			code += "\n    },\n"; // Добавляем код
		}
		picture_box.Image = bmp_on_form;							// Отображаем картинку на форме
		code += "};"; // Добавляем код
        text_box.Text = code; // Отображаем код в приложении
        //File.WriteAllText(@"D:\lcd_image.h", code);  
    }
    
    static void button_start_Click(object sender, EventArgs e){ // Обработчик нажатия кнопки
		string filename; // Имя файла
		OpenFileDialog open_file_dialog = new OpenFileDialog();	// Создаем диалог открытия файла	
    	open_file_dialog.Filter = "BMP files(*.bmp)|*.bmp";		// Устанавливаем отображение bmp
    	//open_file_dialog.InitialDirectory = @"D:\";			// Директория открытия
    	if(open_file_dialog.ShowDialog() == DialogResult.OK){	// Если файл открыт
            filename = open_file_dialog.FileName;		// Получаем полное имя файла (с путем)
            bmp = new Bitmap(filename);					// Создаем BMP из пути к файлу картинки
            slider.Parent = mainForm; // Устанавливаем принадлежность TrackBar форме   
            print_and_draw(); // Рисуем картинку, сохраняем код в файл и выводим его на экран           
    	}
    } 
    
    static void slider_changed(object sender, EventArgs e){
    	print_and_draw(); // Рисуем картинку, сохраняем код в файл и выводим его на экран     
    }
    
} // End class